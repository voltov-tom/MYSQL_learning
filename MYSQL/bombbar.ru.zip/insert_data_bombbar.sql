INSERT INTO CATALOGS (NAME) VALUES
	('БАТОНЧИКИ'), ('ПАСТЫ ОРЕХОВЫЕ'), ('СМЕСИ ДЛЯ ВЫПЕЧКИ'), ('КОКТЕЛИ ПРОТЕИНОВЫЕ'), ('ПЕЧЕНЬЕ'),	('КОНФЕТЫ ПРОТЕИНОВЫЕ'), ('ПОДАРОЧНЫЕ НАБОРЫ'),	('ДЖЕМЫ НИЗКОКАЛОРИЙНЫЕ');

INSERT INTO USERS (NAME, BIRTHDAY_AT, EMAIL, TEL) VALUES
	('РАФИС', '1990-10-05', 'GENA@EXAMPLE.COM', 9093213413),
	('НАТАЛЬЯ', '1984-11-12', 'NATA@EXAMPLE.COM', 9043597413),
	('АЛЕКСАНДР', '1985-05-20', 'ALEX@EXAMPLE.COM', 9863213456),
	('СЕРГЕЙ', '1988-02-14', 'SERG@EXAMPLE.COM', 9863213123),
	('ИВАН', '1998-01-12', 'IVAN@EXAMPLE.COM', 9863654356),
	('МАРИЯ', '1992-08-29', 'MARI@EXAMPLE.COM', 9809813456),
	('СТАС', '1999-01-12', 'STAS@EXAMPLE.COM', 9993677356),
	('РОМАН', '1992-08-29', 'ROMAN@EXAMPLE.COM', 9863223416);

INSERT INTO PROMOTIONS (NAME, PROMO_YES_NO) VALUES
	('НЕТ СКИДКИ', 0), ('-10%', 1), ('-15%', 1), ('-20%', 1);
	
INSERT INTO PHOTOS (NAME, `SIZE`, LINK) VALUES
	('ASSORTED', 123, 'HTTP://EXAMPLE.COM/DIR1/XYZ123.PNG'),
	('RICE_BAR', 124, 'HTTP://EXAMPLE.COM/DIR1/XYZ124.PNG'),
	('CHOCOLATE_SPREAD', 125, 'HTTP://EXAMPLE.COM/DIR1/XYZ125.PNG'),
	('PANCACE', 126, 'HTTP://EXAMPLE.COM/DIR1/XYZ126.PNG'),
	('MALINOVOE_PECHENE', 127, 'HTTP://EXAMPLE.COM/DIR1/XYZ127.PNG'),
	('SHOKOLADNIY_BRAUNI', 128, 'HTTP://EXAMPLE.COM/DIR1/XYZ128.PNG'),
	('KONFETI_PROTEINOVIE_FINIK', 129, 'HTTP://EXAMPLE.COM/DIR1/XYZ129.PNG'),
	('PODAROCHNIY_NABOR_CHIKALAB', 130, 'HTTP://EXAMPLE.COM/DIR1/XYZ130.PNG'),
	('PODAROCHNIY_NABOR_CHIKALAB_MAX', 131, 'HTTP://EXAMPLE.COM/DIR1/XYZ131.PNG');
	
INSERT INTO PRODUCTS (NAME, DESCRIPTION, PRICE, CATALOG_ID, PROMOTION_ID, PHOTO_ID) VALUES
	('АССОРТИ', 'ШОУБОКС СОДЕРЖИТ ВСЕ ВКУСЫ БАТОНЧИКОВ CHIKALAB', 1800, 1, 2, 1),
	('РИСОВЫЙ', 'РИС БОГАТ ВИТАМИНАМИ И МИНЕРАЛАМИ', 1200, 1, 1, 2),
	('ШОКОЛАДНАЯ ПАСТА С ФУНДУКОМ', 'ФУНДУК СНИЖАЕТ УРОВЕНЬ ВРЕДНОГО ХОЛЕСТЕРИНА', 350, 2, 2, 3),
	('ПАНКЕЙКИ С ТВОРОГОМ', 'ТВОРОГ СОДЕРЖИТ ВИТАМИНЫ ГРУППЫ В, КАЛЬЦИЙ, ФОСФОР, СЕЛЕН', 500, 3, 3, 4),
	('МАЛИНОВОЕ ПЕЧЕНИЕ', 'МАЛИНА, МОЛОКО... МОЛОЧНЫЙ КОКТЕЙЛЬ... ВКУС ДЕТСТВА', 1200, 4, 2, 5),
	('ПРОТЕИНОВОЕ ПЕЧЕНИЕ ФИНИК', 'ФИНИКИ СОДЕРЖАТ ВИТАМИНЫ A, E.', 700, 6, 4, 7),
	('ШОКОЛАДНЫЙ БРАУНИ', 'ШОКОЛАД  СНИЖАЕТ РИСК ИНСУЛЬТА – В СРЕДНЕМ НА 17%. ИСТОЧНИК КАЛИЯ, ЦИНКА И СЕЛЕНА.', 720, 5, 2, 6),
	('ПОДАРОЧНЫЙ НАБОР ЧИКАЛАБ', 'ПОДАРОЧНЫЙ НАБОР  - КЛАССНЫЙ ПОДАРОК ДЛЯ ТЕХ, КТО СЛЕДИТ ЗА СВОИМ ПИТАНИЕМ И ЗДОРОВЬЕМ.', 3200, 7, 3, 8),
	('ПОДАРОЧНЫЙ НАБОР ЧИКАЛАБ МАКС', 'ПОДАРОЧНЫЙ НАБОР  - КЛАССНЫЙ ПОДАРОК ДЛЯ ТЕХ, КТО СЛЕДИТ ЗА СВОИМ ПИТАНИЕМ И ЗДОРОВЬЕМ.', 4000, 8, 1, 9);
	
INSERT INTO ORDERS (USER_ID, PRODUCT_ID) VALUES
	(1, 1),	(1, 2),	(1, 5),	(2, 2),	(3, 3),	(4, 2),	(5, 8);

INSERT INTO REVIEWS (STARS, USER_ID, PRODUCT_ID, BODY) VALUES
	(5, 1, 1, 'МНЕ ПОНРАВИЛОСЬ, РЕКОМЕНДУЮ'),
	(4, 1, 2, 'МНЕ НЕ ПОНРАВИЛОСЬ, НО РЕКОМЕНДУЮ'),
	(5, 1, 5, 'МНЕ ПОНРАВИЛОСЬ, СОВЕТУЮ, ВКУС ЧТО НАДО'),
	(3, 2, 2, 'ТАК СЕБЕ'),
	(5, 3, 3, 'МНЕ ПОНРАВИЛОСЬ, РЕКОМЕНДУЮ'),
	(4, 4, 2, 'ПРИЕХАЛО ПОМЯТЫМ, НО НА ВКУС НЕ ПОВЛИЯЛО'),
	(1, 5, 8, 'ЗАКАЗЫВАЮ В ПОСЛЕДНИЙ РАЗ, ТАК ОНИ МНЕ НЕ ПОНРАВИЛИСЬ');
	
INSERT INTO STOREHOUSES (NAME) VALUES 
	('ОСНОВНОЙ'), ('РЕЗЕРВ');
	
INSERT INTO STOREHOUSES_PRODUCTS (STOREHOUSE_ID, PRODUCT_ID, VALUE) VALUES
	(1, 1, 100), (1, 2, 111), (1, 3, 100), (1, 4, 234), (1, 5, 34), (1, 6, 567), (1, 7, 200), (1, 8, 0), (1, 9, 0), (2, 8, 20), (2, 9, 19);